# Fivem-Chat
Edit of the main fivem chat script. The chat was edited thanks to morris. 

# Features
- When you click tab when you have chat opended it will automatically set your message as the first suggestion. 
- Chat is a bit smaller has a nicer shape

# Setup
- Delete the chat folder which can be found within the [gameplay] folder then add the chat resource in the place of the old chat resource
