config = {}

config.words = {
    "fuck",
    "faggot",
    "kys"
}

config.retrun_message = "[^3SYSTEM^0] You cannot say ^1%s^0 in this server!"